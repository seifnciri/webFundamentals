const changeText = document.querySelector("#btn");

changeText.addEventListener("click", function() {
  changeText.textContent = "Logout";
});

const btn = document.getElementById('disp');

btn.addEventListener('click', () => {

  btn.style.display = 'none';


  const box = document.getElementById('box');
  box.style.display = 'block';
});

document.getElementById("d").addEventListener("click", function() {
    alert("Ninja was liked");
  });