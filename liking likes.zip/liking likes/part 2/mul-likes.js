function liking(element){
    document.getElementById(element).innerText++;

}